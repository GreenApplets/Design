/**
	DAO.java is the Data Access Object class in this package.
	It contains methods that writes and reads the file where the tasks are stored and to be added.
	This also includes an extra method displayTask(Task) just to display that the content of the file as changes are made.
	Author: Algina Castillo
**/
import java.util.*;
import java.io.*;

public class DAO
{
	File file= new File("Samp.txt"); //file where the tasks are written
	
	
	/**
		writeToFile() writes the task by appending it to the Samp.txt
		@param add is the task of which details are to be stored or written
	**/
	public void writeToFile(Task add) throws IOException
	{
		if(file.exists()==false)
		{
			file.createNewFile();				
		}
			BufferedWriter bw= new BufferedWriter(new FileWriter(file, true)); //true is for appending
			bw.write(add.taskname + ";" + add.desc + ";" + add.venue + ";" + add.ddl + ";" + add.pic.getPICName() + ";" + add.pic.getPassword()+"\n");
			bw.close();
	}
	
	
	/**
		readFromFile() reads the content of Samp.txt 
	**/
	public void readFromFile() throws IOException
	{
		Planimal p=new Planimal();
		if(file.exists()==false)
		{
			file.createNewFile();
		}
		BufferedReader br= new BufferedReader(new FileReader(file));
		String line=br.readLine();
		while(line!= null )
		{
			String[] data= line.split(";");						
			Task b= new Task(data[0], data[1], data[2], data[3],data[4], data[5]);
			displayTask(b);					//calls displayTask(Task) method to output the read data to the console
			line=br.readLine();
		}
		br.close();
	}

	/**
		displayTask() method outputs the details of the task to the cmd 
		@param curr is the task to printed in the console
	**/
	public static void displayTask(Task curr)
	{
		System.out.println("\n"+ curr.taskname);
		System.out.println("\t"+ curr.desc);
		System.out.println("\t"+ curr.venue);
		System.out.println("\t"+ curr.deadline);
		System.out.println("\t" + curr.pic.getPICName() +"\n");	
	
	}

}