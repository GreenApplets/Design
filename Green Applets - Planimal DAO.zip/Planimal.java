/**
	Planimal.java is the business object class.
	This is where the main thread is and links the DataAccessObject class(i.e. DAO.java) to Transfer object classes. 
	Author: Algina Castillo
**/

import java.io.*;
import java.util.*;

public class Planimal
{
	
	public static void main(String args[]) throws IOException
	{
	
		System.out.println("#####################################################\n\nWelcome to Planimal!\n");
		while(true)
		{
			showMenu();				
			getChoice();
		}
	}
	
	
	/**
		showMenu() displays the menu or the list of actions a user is allowed to do
	**/
	public static void showMenu()
	{
		
		System.out.println("1.Add Task");
		System.out.println("2.View all tasks");
		System.out.println("3.Exit\n");
		System.out.print("Enter your choice:\t");
	}
	
	/** 
		getChoice() gets what number the user chooses from the menu or options and perform operations such as calling another function corresponding to that choice
	**/	
	public static void getChoice() 
	{
		DAO dao= new DAO();							//makes an instance of the data access object class DAO
		Scanner sc= new Scanner(System.in);
		int command=sc.nextInt();					//int command is the number the user has input from the menu
		switch(command)
		{
			case 1:									//the chosen command is "add task" 
				taskInput();						//calls the taskInput()
				break;
			case 2:									//the chosen command is "view all tasks"
				try{
				dao.readFromFile();					//calls the readFromFile() to read the file content
				}catch(IOException io){}
				break;
			case 3:
				System.exit(1);
				break;
			default:
				System.out.println("Please enter numbers between 1 and 3 inclusive only."); //error
		}
	
	}
	
	/**
		taskInput() prompts the user to input the details of the task he or she wants to add
	**/
	public static void taskInput()
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("TaskName:\t");
		String task_name= sc.nextLine();
		System.out.print("Description:\t");
		String task_desc= sc.nextLine();
		System.out.print("Venue:\t");
		String task_venue= sc.nextLine();
		System.out.print("Deadline:\t");
		String task_dd= sc.nextLine();
		System.out.print("Person-In-Charge:\t");
		String task_pic= sc.nextLine();
		System.out.print("Password:\t");
		String task_pw=sc.nextLine();
		Task k=new Task(task_name, task_desc, task_venue, task_dd,task_pic, task_pw);
		saveOrCancel(k);
	}
	
	/**
		saveOrCancel() asks the user whether to save the task or not
		@param temp is the task that the user has to decide whether to save or not
	**/
	public static void saveOrCancel(Task temp) 
	{
		DAO dao = new DAO();
		System.out.println("1.Save");
		System.out.println("2.Cancel");
		Scanner sc= new Scanner(System.in);
		int cancel=sc.nextInt();
		if (cancel==1){									//save the task
			try{
			dao.writeToFile(temp);						//calls the writeToFile(Task) to append the task information to the file
			System.out.println("\n"+ temp.taskname +" has been added\n");
			}catch(IOException Ioe){}
		}
		else if(cancel!=0 && cancel!=1){				//error
			System.out.println("Input 1 or 2 only.");
			saveOrCancel(temp);
		}
	}
	
}