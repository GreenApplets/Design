/**
	Task.java is a Transfer Object Class.
	It defines the attributes of Person-in-charge entity and provides the methods needed such as setters/constructors and helping method like convert().
	Author: Algina Castillo
**/


import java.util.*;
import java.text.*;

public class Task
{
		String taskname;
		String desc;
		String venue;
		String ddl;
		Date deadline;
		PersonInCharge pic;
		
		public Task()
		{
			
		}
	 
		public Task(String taskname, String desc, String venue,String deadline, String personIC, String password)
		{
			this.taskname= taskname;
			this.desc=desc;
			this.ddl=deadline;
			try{
			this.deadline=convert(deadline);}
			catch(ParseException pe){}
			this.venue=venue;
			this.pic=new PersonInCharge(personIC, password);
		}
		
		/**
			convert() method parse the given String to Dare
			@param date is the string to be parsed into Date
			@return dd is the Date form or value of parameter date
		**/
		public Date convert(String date) throws ParseException
		{
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm"); 
			Date dd = df.parse(date);
			return dd;
		}
}