package com.greenapplets.planimal;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.support.v7.app.ActionBarActivity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends ActionBarActivity {
	final Context context = this;
	
	Button add;
	Button toPet;
	Button toSchedule;
	Button toShop; 
	Button addPIC;
	
	boolean isPromptUp = false;
	
	List<Task> taskList = new ArrayList<Task>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		getSupportActionBar().setDisplayShowHomeEnabled(true);
		getSupportActionBar().setIcon(R.drawable.ic_launcher);
		
		add = (Button) findViewById(R.id.addTask);
		
		// jfc this is so long
		// add listener to add button
		add.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(!isPromptUp){
					isPromptUp = true;
												
					LayoutInflater li = LayoutInflater.from(context);
					View promptView = li.inflate(R.layout.prompt_add, null);
					
					AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
					
					alertDialogBuilder.setView(promptView);
					
					final EditText editPIC = (EditText) promptView.findViewById(R.id.editPIC);
					final EditText editName = (EditText) promptView.findViewById(R.id.editName);
					final EditText editPassword = (EditText) promptView.findViewById(R.id.editPassword);
					final EditText editVenue = (EditText) promptView.findViewById(R.id.editVenue);
					final DatePicker deadline = (DatePicker) promptView.findViewById(R.id.datePicker1);
					
					alertDialogBuilder
					.setCancelable(false)
					.setPositiveButton("OK",
					  new DialogInterface.OnClickListener() {
					    @SuppressWarnings("deprecation")
						public void onClick(DialogInterface dialog,int id) {
						// where you assign input to variables
					    // eg: someVariable.setText(picInput.getText()); i think owo;;;
					    	Task nuTask = new Task();
					    	
					    	nuTask.setPic(editPIC.getText().toString());
					    	nuTask.setVenue(editVenue.getText().toString());
					    	nuTask.setName(editName.getText().toString());
					    	nuTask.setPassword(editPassword.getText().toString());
					    	nuTask.setDeadline(new Date(deadline.getYear() - 1900, 
					    			deadline.getMonth(), deadline.getDayOfMonth()));
					    	
					    	
					    		taskList.add(nuTask);
					    		populateList();
					    	
					    	
					    	isPromptUp = false;
					    }
					  })
					.setNegativeButton("Cancel",
					  new DialogInterface.OnClickListener() {
					    public void onClick(DialogInterface dialog,int id) {
					    	isPromptUp = false;
					    	dialog.cancel();
					    }
					  });
					
					AlertDialog alertDialog = alertDialogBuilder.create();
					
					alertDialog.show();
				}
			}
		});
	}
	
	public void populateList(){
		String[] fill = new String[taskList.size()];
		
		for(int i = 0; i < taskList.size(); i++){
			fill[i] = taskList.get(i).getTask();
		}
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_task, fill); 
		
		ListView list = (ListView) findViewById(R.id.taskList);
		list.setAdapter(adapter);
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
