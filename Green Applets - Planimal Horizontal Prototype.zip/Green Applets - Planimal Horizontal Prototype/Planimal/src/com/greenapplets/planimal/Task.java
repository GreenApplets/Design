package com.greenapplets.planimal;

import java.util.Calendar;
import java.util.Date;

public class Task {
	String name = null;
	String pic = null;
	String venue = null;
	String password = null;
	Date deadline = null;
		
	public boolean isEmpty(){
		if(name == null || pic == null || venue == null || password == null || deadline == null){
			return true;			
		}
		
		return false;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String notes) {
		this.venue = notes;
	}
	public Date getDeadline() {
		return deadline;
	}
	public void setDeadline(Date deadline) {
		this.deadline = deadline;
	}
	
	public String getTask(){
		String task = new String();
		String days[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
		
		Calendar cal = Calendar.getInstance();
	    cal.setTime(deadline);
	    int year = cal.get(Calendar.YEAR);
	    int month = cal.get(Calendar.MONTH) + 1;
	    int day = cal.get(Calendar.DAY_OF_MONTH);
	    
	    task = month + "/" + day + "/" + year + " - " + days[cal.get(Calendar.DAY_OF_WEEK) - 1] + "\n" +
	    		name + "-" + venue + "\n";
		
		return task;		
	}
	
}
